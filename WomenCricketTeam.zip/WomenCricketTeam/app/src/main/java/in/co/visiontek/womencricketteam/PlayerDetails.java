package in.co.visiontek.womencricketteam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class PlayerDetails extends AppCompatActivity {
TextView nameTvD,roletVD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_details);
        nameTvD=findViewById(R.id.tv_namedetails);
        roletVD=findViewById(R.id.tv_roledetails);
        ActionBar actionBar = getSupportActionBar();
        ((ActionBar) actionBar).setDisplayHomeAsUpEnabled(true);

        Intent in=getIntent();
        WomenPlayer womenPlayer= (WomenPlayer) in.getSerializableExtra("player");
        nameTvD.setText(womenPlayer.getName());
        roletVD.setText(womenPlayer.getRole());
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent i=new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);
        return super.onOptionsItemSelected(item);
    }

    }