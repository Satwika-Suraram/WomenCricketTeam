package in.co.visiontek.womencricketteam;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.MyViewHolder> {
    Context context;
    ArrayList<WomenPlayer> playerArrayList;
    int currentPosition;
    String UpdName,UpdRole;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    public PlayerAdapter(Context context, ArrayList<WomenPlayer> playerArrayList) {
        this.context = context;
        this.playerArrayList = playerArrayList;
    }

    @NonNull
    @Override
    public PlayerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.card_items,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayerAdapter.MyViewHolder holder, int position) {
        WomenPlayer womenPlayer = playerArrayList.get(position);
        holder.nameTv.setText(womenPlayer.getName());
        holder.roleTv.setText(womenPlayer.getRole());
        if (womenPlayer.getRole().equals("Batter")){
            holder.img.setImageResource(R.drawable.batter);
        }
        if (womenPlayer.getRole().equals("Bowler")){
            holder.img.setImageResource(R.drawable.bowl);
        }
        if (womenPlayer.getRole().equals("AllRounder")){
            holder.img.setImageResource(R.drawable.allrounder);
        }
        if (womenPlayer.getRole().equals("WicketKeeper")){
            holder.img.setImageResource(R.drawable.wicketkeeper);
        }
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                PopupMenu popupMenu = new PopupMenu(context, v);
                popupMenu.getMenuInflater().inflate(R.menu.popup_options, popupMenu.getMenu());
                currentPosition = holder.getAdapterPosition();
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.edit:
                                editState();
                                break;
                            case R.id.del:
                                deleteState();
                                break;
                        }
                        return true;
                    }
                });
                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(context,PlayerDetails.class);
                in.putExtra("player",womenPlayer);
                v.getContext().startActivity(in);
            }
        });
    }

    private void deleteState() {
        WomenPlayer womenPlayer=playerArrayList.get(currentPosition);
        databaseReference=FirebaseDatabase.getInstance().getReference("Women Players");
        Query delQuery = databaseReference.orderByChild("name").equalTo(womenPlayer.getName());
        delQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                    appleSnapshot.getRef().removeValue();
                }
                notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void editState() {
        Dialog dialog=new Dialog(context);
        dialog.setContentView(R.layout.edit_dialogue);
        dialog.show();
        EditText nameUpdate=dialog.findViewById(R.id.nameUpd);
        EditText roleUpdate=dialog.findViewById(R.id.capitalUpd);
        Button update=dialog.findViewById(R.id.upd_btn);
        WomenPlayer womenPlayer=playerArrayList.get(currentPosition);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdName=nameUpdate.getText().toString();
                UpdRole=roleUpdate.getText().toString();
            }
        });

    }

    @Override
    public int getItemCount() {
        return playerArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nameTv,roleTv;
        ImageView img;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTv=itemView.findViewById(R.id.name_tv);
            roleTv=itemView.findViewById(R.id.role_tv);
            img=itemView.findViewById(R.id.imgView);
        }
    }
}
