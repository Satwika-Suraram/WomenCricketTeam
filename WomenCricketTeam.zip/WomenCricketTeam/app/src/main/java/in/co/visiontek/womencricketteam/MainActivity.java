package in.co.visiontek.womencricketteam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
Spinner spinnerName,spinnerRole;
    Button addBtn;
    String name,role;
    RecyclerView recyclerView;
    ArrayList<WomenPlayer> playerArrayList;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerView);
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("Women Players");
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                playerArrayList=new ArrayList<>();
                PlayerAdapter playerAdapter = new PlayerAdapter(getApplicationContext(), playerArrayList);
                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                    WomenPlayer womenPlayer=dataSnapshot.getValue(WomenPlayer.class);
                    playerArrayList.add(womenPlayer);

                }
                recyclerView.setAdapter(playerAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Dialog dialog=new Dialog(this);
        dialog.setContentView(R.layout.activity_dialogue_spinner);
        spinnerName=dialog.findViewById(R.id.spinnername);
        spinnerRole=dialog.findViewById(R.id.spinnerrole);
       /* name=dialog.findViewById(R.id.name);
        role=dialog.findViewById(R.id.role);*/
        addBtn=dialog.findViewById(R.id.addBtnDialogue);
        ArrayAdapter<CharSequence> nameadapter=ArrayAdapter.createFromResource(getApplicationContext(),R.array.womenPlayers, android.R.layout.simple_spinner_dropdown_item);
        spinnerName.setAdapter(nameadapter);
        ArrayAdapter<CharSequence> roleadapter=ArrayAdapter.createFromResource(getApplicationContext(),R.array.roleList, android.R.layout.simple_spinner_dropdown_item);
        spinnerName.setAdapter(nameadapter);
        spinnerRole.setAdapter(roleadapter);
        spinnerName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                name=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinnerRole.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                role=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        dialog.show();

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToFireBaseDb(name,role);
                dialog.dismiss();
            }
        });
        return super.onOptionsItemSelected(item);
    }

    private void addToFireBaseDb(String name, String role) {
        WomenPlayer womenPlayer=new WomenPlayer(name,role);
        databaseReference.push().setValue(womenPlayer);
    }

   /* @Override
    public void (AdapterView<?> parent, View view, int position, long id) {
    name=spinnerName.getItemAtPosition(position).toString();
    role=spinnerRole.getItemAtPosition(position).toString();
    }*/

}