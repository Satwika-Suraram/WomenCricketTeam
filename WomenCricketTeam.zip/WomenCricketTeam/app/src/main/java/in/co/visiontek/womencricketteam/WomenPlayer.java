package in.co.visiontek.womencricketteam;

import java.io.Serializable;

public class WomenPlayer implements Serializable {
    String name,role;

    public WomenPlayer() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public WomenPlayer(String name, String role) {
        this.name = name;
        this.role = role;
    }
}
